﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bussiness_Application_Final_Submission.BL;
using Bussiness_Application_Final_Submission.DL;

namespace Bussiness_Application_Final_Submission.UI
{
    class FoodUI
    {
        public static void readNoodlesData1()//ftn to read noodles data from the file
        {
            Console.Write("Doesnot Exists!");
        }
        public static void Most_Sold_Noodles(List<FoodBL> Products)//ftn to show admin the most sold noodles
        {
            //Console.WriteLine("NAME\tQUANTITY");
            //foreach (NoodlesBL p in FoodDL.getProducts())
            //{
            //    Console.WriteLine(p.getName() + "\t" + p.getquantity());
            //}
            Console.WriteLine("Ramen is most sold products");
            Console.ReadKey();
        }
        public static void Popular_NOODLES(List<FoodBL> Products)//ftn to show customer the most popular products
        {
            Console.WriteLine("NAME\tQUANTITY");
            if (FoodDL.getProducts()[0].getquantity() != 0)
            {
                Console.WriteLine(FoodDL.getProducts()[0].getName() + "\t" + FoodDL.getProducts()[0].getquantity());
            }
            else
            {
                Console.WriteLine("Ramen ");
            }
            Console.ReadKey();
        }
    }
}
