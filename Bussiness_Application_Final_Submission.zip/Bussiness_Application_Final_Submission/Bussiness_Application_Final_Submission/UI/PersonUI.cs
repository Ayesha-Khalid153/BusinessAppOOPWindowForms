﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bussiness_Application_Final_Submission.BL;

namespace Bussiness_Application_Final_Submission.UI
{
   
    class PersonUI
    {
        public static string Menu() //function to show the main menu of user
        {
            Console.Clear();
            NoodlesUI.topHeader();//ftn prints header
            NoodlesUI.logo();//ftn prints logo
            string option;
            bool check = false;
            Console.WriteLine("1.SignUp with you Credential");
            Console.WriteLine("2.SignIn with you Credential");
            Console.WriteLine("3.Exit the Application");
            Console.WriteLine("Enter Your Option : ");
            option = Console.ReadLine();
            for (int i = 1; i <= 13; i++)
            {
                if (option == i.ToString())
                {
                    option = i.ToString();
                    check = true;
                    break;
                }
            }
            if (!check)
            {
                Console.WriteLine("Invalid option. Please enter a number between 1 and 13.");
                Console.ReadKey();
                option = Menu();
            }
            return option;
        }
        public static PersonBL takeInputWithoutRole()//ftn to take input of the user without role
        {
            Console.WriteLine("Enter Name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Password: ");
            string password = Console.ReadLine();
            if (name != null && password != null)
            {
                PersonBL user = new PersonBL(name, password);
                return user;
            }
            return null;
        }
        public static PersonBL takeInputWithRole()//ftn to take input of the user with role
        {

            Console.WriteLine("Enter Name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Password: ");
            string password = Console.ReadLine();
            Console.WriteLine("Enter Role: ");
            string role = Console.ReadLine();
            if (name != null && password != null && role != null)
            {
                PersonBL user = new PersonBL(name, password, role);
                return user;
            }
            return null;
        }
    }
}
