﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bussiness_Application_Final_Submission.BL;
using Bussiness_Application_Final_Submission.DL;

namespace Bussiness_Application_Final_Submission.UI
{
    class NoodlesUI
    {
        public static NoodlesBL create(string path1) //ftn through which admin aadds the noodles details
        {
            Console.Clear();
            while (true)
            {
                Console.WriteLine("Enter the name of the noodle: ");
                string name = Console.ReadLine();

                if (name.ToLower() == "ramen" || name.ToLower() == "egg noodles" || name.ToLower() == "tokoroten" || name.ToLower() == "ho fun" || name.ToLower() == "rice stick")
                {
                    Console.WriteLine("Enter the actual price of noodle: ");
                    double actualPrice = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the sale price of noodle: ");
                    double salePrice = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the stock of this noodle: ");
                    int stock = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the discount of this noodle: ");
                    double discount = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the tasteMaker of this noodle: ");
                    string tasteMaker = Console.ReadLine();
                    if (tasteMaker == "true" || tasteMaker == "false")
                    {
                        NoodlesBL o = new NoodlesBL(name, actualPrice, salePrice, stock, discount, tasteMaker);//constructor
                        FoodDL.addFood(o);//storing object in list

                        FoodDL.writeItemDataInFile(path1);

                        Console.Clear();

                        return o;
                    }
                    else
                    {
                        Console.WriteLine("InValid Input!");
                        Console.WriteLine("Please enter true or false...(whether the tastemaker is added in the noodles or all the ingredients are natural)");
                        Console.ReadKey();
                    }
                }

                else
                {
                    Console.WriteLine("InVvalid noodles name! Please add from the following List");
                    Console.WriteLine("1. ramen");
                    Console.WriteLine("2. egg noodles");
                    Console.WriteLine("3. tokoroten");
                    Console.WriteLine("4. ho fun");
                    Console.WriteLine("5. rice stick");
                    Console.ReadKey();
                }
            }

        }
        public static bool Validation(string input)
        {
            bool check_Validation = true;
            for (int i = 0; i < input.Length; i++)
            {
                if (!((input[i] >= 'a' && input[i] <= 'z') || (input[i] >= 'A' && input[i] <= 'Z')))
                {
                    check_Validation = false;
                }
            }
            if (input.Length > 10)
            {
                check_Validation = false;
            }
            return check_Validation;
        }


        public static void delete(string path1)//ftn to delete the noodles details
        {
            Console.Clear();

            Console.Write("Enter Position of item you want to delete: ");
            int itemPos = int.Parse(Console.ReadLine());
            if (itemPos > 0 && itemPos < 20)
            {
                FoodDL.getProducts().RemoveAt(itemPos);//removing noodles at particlar index
                Console.WriteLine("Item has deleted!");
                Console.WriteLine("Press any key to continue");
                FoodDL.writeItemDataInFile(path1);
            }
            else
            {
                Console.WriteLine("Please enter numeric value!");
            }
            Console.ReadKey();



        }
        public static void update(string path1)//ftn to update noodles details
        {
            Console.Clear();
            bool flag = false;

            Console.Write("Enter Position of item you want to update: ");
            int pos = int.Parse(Console.ReadLine());
            if (pos > 0 && pos < 20)
            {
                foreach (NoodlesBL storedUser in FoodDL.getProducts())
                {
                    if (pos <= FoodDL.getProducts().Count)
                    {
                        flag = true;
                    }
                    if (flag == true)
                    {
                        Console.WriteLine("Enter new price of item: ");
                        int salePrice = int.Parse(Console.ReadLine());
                        storedUser.setsalePrice(salePrice);
                        Console.WriteLine("Enter new stock of item: ");
                        int stock = int.Parse(Console.ReadLine());
                        storedUser.setstock(stock);
                        break;
                    }
                }
                if (flag == false)
                {
                    Console.WriteLine("Item don't exist");
                }
                Console.WriteLine("Press any key to continue");
                Console.ReadKey();
                FoodDL.writeItemDataInFile(path1);
            }
            else
            {
                Console.WriteLine("Please enter numeric value!");
            }

        }
        public static void reterieve()//ftn to view the details of noodles to admin
        {
            Console.Clear();
            Console.WriteLine("Name " + " : " + "Actual price " + " : " + "Sales price " + " : " + "Stock" + " : " + "Discount");
            foreach (NoodlesBL storedUser in FoodDL.getProducts())
            {
                Console.WriteLine(storedUser.getName() + "\t:\t" + storedUser.getactualPrice() + "\t:\t" + storedUser.getsalePrice() + "\t:\t" + storedUser.getstock() + "\t:\t" + storedUser.getsdiscount());
            }
        }
        public static double Discount(NoodlesBL c)//ftn throght which admin gives the discount
        {
            bool flag_discount = false;
            string temp_name = "";
            Console.Clear();
            Console.WriteLine("Name " + " : " + "Sales price " + " : " + "Stock" + " : " + "Discount");
            foreach (NoodlesBL storedUser in FoodDL.getProducts())
            {
                Console.WriteLine(storedUser.getName() + "\t:\t" + "\t:\t" + storedUser.getsalePrice() + "\t:\t" + storedUser.getstock() + "\t:\t" + storedUser.getsdiscount());
            }
            Console.WriteLine("Enter the name of the noodles you wanna give discount on: ");
            temp_name = Console.ReadLine();

            foreach (NoodlesBL p in FoodDL.getProducts())
            {
                if (temp_name == p.getName())
                {
                    flag_discount = true;
                    c = p;
                    break;
                }
            }
            if (flag_discount == true)
            {
                Console.WriteLine("Enter the discount:  ");
                double discount1 = double.Parse(Console.ReadLine());
                c.setsdiscount(discount1);
                return c.getsdiscount();
            }
            else if (flag_discount == false)
            {
                Console.WriteLine("Item don't exist");
            }
            return 0;
        }
        public static void topHeader()//ftn to print header
        {
            Console.WriteLine("****************************************************");
            Console.WriteLine("*****************THE TWIRLING FORKS*****************");
            Console.WriteLine("****************************************************");
        }

        public static void logo()//ftn to print logo
        {
            Console.WriteLine(" _____    _____    _____                 ");
            Console.WriteLine("|_   _|  |_   _|  | ___|    || || ||     ");
            Console.WriteLine("  | |      | |    | |_      ||_|| ||    ");
            Console.WriteLine(" /| |/    /| |/  /|  _|/    |__  __|    ");
            Console.WriteLine("  |_|      |_|    |_|          ||       ");
            Console.WriteLine(" _/ \\_    _/ \\_  _/ \\_         ||       ");
        }

    }
}
