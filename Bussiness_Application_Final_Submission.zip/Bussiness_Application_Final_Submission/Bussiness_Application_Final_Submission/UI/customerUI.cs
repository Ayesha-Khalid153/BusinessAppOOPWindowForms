﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bussiness_Application_Final_Submission.BL;
using Bussiness_Application_Final_Submission.DL;

namespace Bussiness_Application_Final_Submission.UI
{
    class customerUI
    {
        public static void customer_services()
        {
            Console.Clear();
            Console.WriteLine("Service type: ");
            Console.WriteLine("Take away Service..");
            Console.WriteLine("Delievery Servie..");
        }

        public static void customer_addToCart(customerBL obj)
        {
            Console.WriteLine("Name " + " : " + "Sales price " + " : " + "Stock" + " : " + "Discount");
            foreach (NoodlesBL storedUser in FoodDL.getProducts())
            {
                Console.WriteLine(storedUser.getName() + "\t:\t" + "\t:\t" + storedUser.getsalePrice() + "\t:\t" + storedUser.getstock() + "\t:\t" + storedUser.getsdiscount());
            }
            customerBL customer = customerDL.getCustomerByNameAndPassword(obj.getname(), obj.getpassword());


            if (customer != null)
            {
                Console.WriteLine("Do you want to add a product to the cart (yes/no): ");
                string response = Console.ReadLine();

                if (response.ToLower() == "yes")
                {
                    Console.WriteLine("Enter the name of the product: ");
                    string productName = Console.ReadLine();

                    Console.WriteLine("Enter the quantity of the product to add to your cart: ");
                    int quantityToAdd = int.Parse(Console.ReadLine());

                    NoodlesBL product = FoodDL.getProductByName(productName);

                    if (product != null)
                    {
                        if (quantityToAdd <= product.getstock())
                        {
                            product.setstock(product.getstock() - quantityToAdd);
                            NoodlesBL newProduct = new NoodlesBL(productName, product.getsalePrice(), product.getsdiscount(), quantityToAdd);
                            customerBL.addBuyProduct(newProduct);

                            Console.WriteLine("Product added to cart successfully.");
                        }
                        else
                        {
                            Console.WriteLine("Insufficient stock for the selected quantity.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Product not found.");
                    }
                }
                else if (response.ToLower() == "no")
                {

                }
                else
                {
                    Console.WriteLine("Invalid input. Try again.");
                }
            }
            else
            {
                Console.WriteLine("Invalid customer. Please check your name and password.");
            }
        }


        public static void customer_menu()
        {
            Console.Clear();
            Console.WriteLine("MENU:");
            Console.WriteLine("1.Egg noodles.");
            Console.WriteLine("2.Ramen noodles.");
            Console.WriteLine("3.Ho Fun noodles.");
            Console.WriteLine("4.Rice Stick noodles.");
            Console.WriteLine("5.Tokoroten noodles.");
        }
        public static customerBL Add_Customer_Info()
        {
            Console.WriteLine("Enter your name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter your password: ");
            string password = Console.ReadLine();
            Console.WriteLine("Enter your address: ");
            string address = Console.ReadLine();
            Console.WriteLine("Enter your email address: ");
            string email = Console.ReadLine();
            Console.WriteLine("Enter your contact number: ");
            string contact = Console.ReadLine();

            customerBL customerObj = new customerBL(name, password, address, contact, email);
            customerDL.getaddCustomer().Add(customerObj);

            return customerObj;
        }
        public static void customer_view_Menu()
        {
            Console.Clear();
            Console.WriteLine("Noodle type name " + " : " + "Noodle sales price " + " : " + "Stock of noodles" + " : " + "discount on noodles");
            foreach (NoodlesBL storedUser in FoodDL.getProducts())
            {
                Console.WriteLine(storedUser.getName() + "\t:\t" + "\t:\t" + storedUser.getsalePrice() + "\t:\t" + storedUser.getquantity() + "\t:\t" + storedUser.getsdiscount());
            }
        }
        public static string Customer_feedback()
        {

            Console.WriteLine("Enter customer name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Feedback:");
            string feedback = Console.ReadLine();


            Console.WriteLine("Feedback entered successfully!");
            return feedback;
        }

        public static void Remove_From_Cart()
        {
            Console.WriteLine("Name\t:\tSales price\t:\tStock\t:\tDiscount");

            foreach (NoodlesBL storedUser in customerBL.getBuyProducts())
            {
                if (storedUser.getquantity() != 0)
                {
                    Console.WriteLine("{0}\t:\t{1}\t:\t{2}\t:\t{3}", storedUser.getName(), storedUser.getsalePrice(), storedUser.getquantity(), storedUser.getsdiscount());
                }
            }

            Console.WriteLine("Do you want to remove noodles from the cart (yes/no): ");
            string option = Console.ReadLine();

            if (option.ToLower() == "yes")
            {
                Console.WriteLine("ENTER THE NAME OF THE NOODLES: ");
                string name = Console.ReadLine();

                Console.WriteLine("ENTER THE QUANTITY OF NOODLES TO REMOVE FROM YOUR CART: ");
                int removeStockFromCart = int.Parse(Console.ReadLine());

                foreach (var p in customerBL.getBuyProducts())
                {
                    if (p.getName().ToLower() == name.ToLower())
                    {
                        p.setquantity(p.getquantity() - removeStockFromCart);
                        p.setstock(p.getstock() + p.getquantity());
                    }
                }
            }
            else if (option.ToLower() == "no")
            {
                return;
            }

            Console.Clear();
        }

        public static double bills()
        {
            double total = 0;
            foreach (var o in customerBL.getBuyProducts())
            {
                total = (o.getsalePrice() * o.getquantity()) - (o.getsalePrice() * o.getquantity() * o.getsdiscount());
                Console.WriteLine("Your total payable bill is : " + total);
                return total;
            }
            return total;
        }

        public static void viewBill(double final_Bill)
        {
            Console.WriteLine("YOUR TOTAL BILL IS : " + final_Bill);
        }
        public static void customerInterface()
        {
            Console.Clear();
            customerBL b = new customerBL();
            string choose = "";

            do
            {
                Console.Clear();
                NoodlesUI.topHeader();//ftn to print header
                NoodlesUI.logo();//ftn to print logo
                choose = customerMainMenu();


                if (choose == "1")
                {
                    Console.Clear();
                    NoodlesUI.topHeader();
                    NoodlesUI.logo();
                    b = Add_Customer_Info();
                    Console.ReadKey();
                }
                if (b.getEmail() == null)
                {
                    Console.Clear();
                    Console.WriteLine("........................................................");
                    Console.WriteLine("..                                                    ..");
                    Console.WriteLine("..                    THENGA!                         ..");
                    Console.WriteLine("..  Pehley ap ja ker apni information add ker key ao  ..");
                    Console.WriteLine("..                                                    ..");
                    Console.WriteLine("........................................................");
                    Console.ReadKey();
                }
                else if (b.getEmail() != null)
                {
                    if (choose == "2")
                    {
                        Console.Clear();
                        NoodlesUI.topHeader();
                        NoodlesUI.logo();
                        customer_services();
                        Console.ReadKey();
                    }

                    if (choose == "3")
                    {
                        Console.Clear();
                        NoodlesUI.topHeader();
                        NoodlesUI.logo();
                        customer_menu();
                        Console.ReadKey();
                    }
                    if (choose == "4")
                    {
                        Console.Clear();
                        NoodlesUI.topHeader();
                        NoodlesUI.logo();
                        FoodDL.sorting(FoodDL.getProducts());
                        Console.ReadKey();

                    }
                    if (choose == "5")
                    {
                        Console.Clear();
                        NoodlesUI.topHeader();
                        NoodlesUI.logo();
                        Console.WriteLine("                                                        ");
                        Console.WriteLine("                                                        ");
                        Console.WriteLine("....................Discounts....................");
                        Console.WriteLine("                                                        ");
                        Console.WriteLine("                                                        ");
                        customer_view_Menu();
                        Console.ReadKey();

                    }
                    if (choose == "6")
                    {
                        Console.Clear();
                        NoodlesUI.topHeader();
                        NoodlesUI.logo();
                        Console.WriteLine("                                                        ");
                        Console.WriteLine("                                                        ");
                        Console.WriteLine("....................Customer Menu....................");
                        Console.WriteLine("                                                        ");
                        Console.WriteLine("                                                        ");
                        customer_menu();
                        Console.ReadKey();
                    }
                    if (choose == "7")
                    {
                        Console.Clear();
                        NoodlesUI.topHeader();
                        NoodlesUI.logo();
                        Console.WriteLine("                                                        ");
                        Console.WriteLine("                                                        ");
                        Console.WriteLine("....................Noodles Data....................");
                        Console.WriteLine("                                                        ");
                        Console.WriteLine("                                                        ");
                        NoodlesUI.reterieve();
                        Console.ReadKey();
                    }

                    if (choose == "8")
                    {
                        Console.Clear();
                        NoodlesUI.topHeader();
                        NoodlesUI.logo();
                        Console.WriteLine("                                                        ");
                        Console.WriteLine("                                                        ");
                        Console.WriteLine("....................Most Sold Noodles....................");
                        Console.WriteLine("                                                        ");
                        Console.WriteLine("                                                        ");
                        FoodUI.Popular_NOODLES(FoodDL.SortByQuntity(FoodDL.getProducts()));
                        Console.ReadKey();
                    }
                    if (choose == "9")
                    {
                        Console.Clear();
                        NoodlesUI.topHeader();
                        NoodlesUI.logo();
                        Console.WriteLine("                                                     ");
                        Console.WriteLine("                                                     ");
                        Console.WriteLine("....................Customer Cart....................");
                        Console.WriteLine("                                                     ");
                        Console.WriteLine("                                                     ");
                        customer_addToCart(b);
                        Console.ReadKey();
                    }
                    if (choose == "10")
                    {
                        Console.Clear();
                        NoodlesUI.topHeader();
                        NoodlesUI.logo();
                        Console.WriteLine("                                                        ");
                        Console.WriteLine("                                                        ");
                        Console.WriteLine("....................Current Customer....................");
                        Console.WriteLine("                                                        ");
                        Console.WriteLine("                                                        ");
                        Console.ReadKey();
                        view_Current_Customer(b);
                        Console.ReadKey();
                    }
                    if (choose == "11")
                    {
                        Console.Clear();
                        NoodlesUI.topHeader();
                        NoodlesUI.logo();
                        Remove_From_Cart();
                        Console.ReadKey();
                    }
                    if (choose == "12")
                    {
                        Console.Clear();
                        NoodlesUI.topHeader();
                        NoodlesUI.logo();
                        bills();
                        Console.ReadKey();
                    }
                    if (choose == "13")
                    {
                        Console.Clear();
                        NoodlesUI.topHeader();
                        NoodlesUI.logo();
                        string feedback = Customer_feedback();
                        AdminDL.feedbackList.Add(feedback);
                        Console.ReadKey();
                    }
                    if (choose == "14")
                    {
                        Console.Clear();
                        NoodlesUI.topHeader();
                        NoodlesUI.logo();
                        View_Order_Detail();
                        Console.ReadKey();
                    }

                    if (choose == "15")
                    {
                        break;
                    }
                    Console.ReadKey();
                }
                Console.Clear();
            } while (choose != "15");
            Console.ReadKey();
        }
        public static string customerMainMenu()
        {
            Console.Clear();
            NoodlesUI.topHeader();
            NoodlesUI.logo();
            bool check = false;
            string option;
            Console.WriteLine("                                            ");
            Console.WriteLine(".............Customer Main Menu.............");
            Console.WriteLine("                                            ");
            Console.WriteLine("                                            ");
            Console.WriteLine("1. Add Customer Information");
            Console.WriteLine("2. Service type");
            Console.WriteLine("3. Menu");
            Console.WriteLine("4. View most to least expensive Items");
            Console.WriteLine("5. Discounts");
            //Console.WriteLine("6. Types of all the noodles");
            //Console.WriteLine("7. Available Types");
            Console.WriteLine("8. View Most Popular noodles");
            Console.WriteLine("9. Add to cart");
            //Console.WriteLine("10. View current customer");
            Console.WriteLine("11. Remove from cart");
            Console.WriteLine("12. View bill");
            Console.WriteLine("13. Give your Feedback here");
            //Console.WriteLine("14. View order details");
            Console.WriteLine("15. Exit");
            Console.WriteLine("Your Option:");

            option = Console.ReadLine();

            for (int i = 1; i <= 15; i++)//validations
            {
                if (option == i.ToString())
                {
                    option = i.ToString();
                    check = true;
                    break;
                }
            }

            if (!check)
            {
                Console.WriteLine("Invalid option. Please enter a number between 1 and 13.");
                Console.ReadKey();
                option = customerMainMenu();
            }

            return option;
        }
        public static void view_Current_Customer(customerBL b)
        {
            foreach (var o in customerBL.getBuyProducts())
            {
                Console.WriteLine("Name :\t" + b.getname());
                Console.WriteLine("Password :\t" + b.getpassword());
            }
        }
        public static void View_Order_Detail()
        {
            Console.WriteLine("Name\t\t\tQuantity");
            foreach (var i in customerBL.getBuyProducts())
            {
                Console.WriteLine(i.getName() + "\t\t" + i.getquantity());
            }

        }
    }
}
