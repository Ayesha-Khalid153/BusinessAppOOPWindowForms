﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bussiness_Application_Final_Submission.BL;
using Bussiness_Application_Final_Submission.DL;

namespace Bussiness_Application_Final_Submission.UI
{
    class AdminUI
    {
        public static void admin_View_feedback()//Function for viewing the Feedbacks of Customers on the Products
        {
            if (AdminDL.feedbackList.Count == 0)
            {
                Console.WriteLine("No feedback available.");
            }
            else
            {
                
                Console.WriteLine("Customer Details:");
                for (int i = 0; i < 1; i++)
                {
                    Console.WriteLine(customerDL.getaddCustomer()[i].getname());
                }
                Console.WriteLine("Feedbacks:");
                for (int i = 0; i < AdminDL.feedbackList.Count; i++)
                {
                    Console.WriteLine(AdminDL.feedbackList[i]);
                }
                

            }
        }

        public static void adminInterface(string path1)//Function for the Main menu of the Admin 
        {
            Console.Clear();
            FoodBL F = new FoodBL();
            NoodlesBL q = new NoodlesBL();
            customerBL b = new customerBL();
            string choose = "";
            do
            {
                Console.Clear();
                NoodlesUI.topHeader();//ftn to print header
                NoodlesUI.logo();//ftn to print logo
                Console.WriteLine("                                         ");
                Console.WriteLine(".............Admin Main Menu.............");
                Console.WriteLine("                                         ");
                choose = adminMainMenu();//fn to open the main menu of the admin
                if (choose == "1")
                {
                    Console.Clear();
                    NoodlesUI.topHeader();//ftn to print header
                    NoodlesUI.logo();//ftn to print logo
                    NoodlesBL ak = NoodlesUI.create(path1);//calling admin ftn to add the noodles details
                    Console.ReadKey();
                }
                if (choose == "2")
                {
                    Console.Clear();
                    NoodlesUI.topHeader();//ftn to print header
                    NoodlesUI.logo();//ftn to print logo
                    NoodlesUI.reterieve();//calling ftn of admin to retrieve the noodles details
                    Console.ReadKey();

                }
                if (choose == "3")
                {
                    Console.Clear();
                    NoodlesUI.topHeader();//ftn to print header
                    NoodlesUI.logo();//ftn to print logo
                    NoodlesUI.update(path1);//calling ftn of admin to update noodles details
                    Console.ReadKey();


                }
                else if (choose == "4")
                {

                    Console.Clear();
                    NoodlesUI.topHeader();//ftn to print header
                    NoodlesUI.logo();//ftn to print logo
                    NoodlesUI.delete(path1); //calling ftn of admin to delete the noodles data
                    Console.ReadKey();

                }
                else if (choose == "5")
                {
                    Console.Clear();
                    NoodlesUI.topHeader();//ftn to print header
                    NoodlesUI.logo();//ftn to print logo
                    NoodlesUI.Discount(q);//calling ftn of admin to give discounts
                    Console.ReadKey();
                }

                else if (choose == "6")
                {
                    Console.Clear();
                    NoodlesUI.topHeader();//ftn to print header
                    NoodlesUI.logo();//ftn to print logo
                    FoodDL.sorting(FoodDL.getProducts());//calling ftn of admin to sort data
                    Console.ReadKey();
                }
                else if (choose == "7")
                {
                    Console.Clear();
                    NoodlesUI.topHeader();//ftn to print header
                    NoodlesUI.logo();//ftn to print logo
                    admin_View_feedback();//calling ftn of admin to  view customers feedbacks
                    Console.ReadKey();

                }
                else if (choose == "8")
                {
                    Console.Clear();
                    NoodlesUI.topHeader();//ftn to print header
                    NoodlesUI.logo();//ftn to print logo
                    FoodUI.Most_Sold_Noodles(FoodDL.SortByQuntity(FoodDL.getProducts()));//calling ftn of admin to  view most sold noodles
                    Console.ReadKey();

                }
                else if (choose == "9")
                {
                    Console.Clear();
                    NoodlesUI.topHeader();//ftn to print header
                    NoodlesUI.logo();//ftn to print logo
                    CalculateProfit();//calling ftn of admin to calculate profit
                    Console.ReadKey();
                    Console.ReadKey();

                }

                else if (choose == "10")
                {
                    break;
                }
                Console.Clear();
            } while (choose != "11");

        }
        public static string adminMainMenu()//Funtion for the Admin Menu
        {
            string option;
            bool check = false;
            Console.WriteLine("1. Add noodles in stock");
            Console.WriteLine("2. View noodles details");
            Console.WriteLine("3. Update price");
            Console.WriteLine("4. Remove noodles from the stock");
            Console.WriteLine("5. Give the discounts on the noodles");
            Console.WriteLine("6. View the sorted data in descending order");
            Console.WriteLine("7. View feedbacks");
            Console.WriteLine("8. View most sold noodles");
            Console.WriteLine("9. Calculate Profit ");
            Console.WriteLine("10. Exit ");
            Console.WriteLine("Enter option : ");
            option = Console.ReadLine();


            for (int i = 1; i < 12; i++)//validation
            {
                if (option == i.ToString())
                {
                    option = i.ToString();
                    check = true;
                    break;
                }
            }
            if (!check)
            {
                Console.WriteLine("Invalid option. Please enter a number between 1 and 12.");
                Console.ReadKey();
                option = adminMainMenu();
            }
            return option;
        }

        public static double CalculateProfit()//function to Calculate The profit of the Products which will be bought in Future 

        {
            Console.WriteLine(" Name :  Actual price : Sales price : Stock : Discount ");
            foreach (NoodlesBL storedUser in FoodDL.getProducts())
            {
                Console.WriteLine(storedUser.getName() + " : " + storedUser.getactualPrice() + " : " + storedUser.getsalePrice() + " : " + storedUser.getstock() + " : " + storedUser.getsdiscount());
            }

            Console.WriteLine("Enter the position for which you want to check the profit: ");
            int position = int.Parse(Console.ReadLine());

            if (position >= 1 && position < FoodDL.getProducts().Count)
            {
                FoodBL f = FoodDL.getProducts()[position];
                double profit = f.getsalePrice() - f.getactualPrice();
                Console.WriteLine("Profit on this noodles is: " + profit);
                return profit;
            }
            else
            {
                Console.WriteLine("Invalid position selected.");
                return 0;
            }
        }
    }
}