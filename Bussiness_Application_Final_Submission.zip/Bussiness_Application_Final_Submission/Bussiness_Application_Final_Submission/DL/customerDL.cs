﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bussiness_Application_Final_Submission.BL;

namespace Bussiness_Application_Final_Submission.DL
{
    class customerDL 
    {
        private static  List<customerBL> customersList = new List<customerBL>(); //list to add the customers
        public static customerBL m = new customerBL();
        internal static List<customerBL> CustomersList { get => customersList; set => customersList = value; } //get and set function of customerList
        //public static List<FoodBL> ProductBuy { get => productBuy; set => productBuy = value; }

        private static List<FoodBL> productBuy;
        
        public static  List<customerBL> getaddCustomer() //get function of customerList
        {
            return customersList;
        }
        public static void addCustomerInList(customerBL temp) //function to add customer in the list
        {
            customersList.Add(temp);
        }
        public static customerBL returnCustomer(string password)//function to add the customer if the passwords are same
        {
            foreach (customerBL p in customersList)
            {
                if (p.getpassword() == password)
                {
                    return p;
                }
            }
            return null;
        }

        
        public static void removeCustomer(string password) //function to remove customer from list
        {
            foreach (customerBL storedUser in customersList)
            {
                if (storedUser.getpassword() == password)
                {
                    customersList.Remove(storedUser);
                }
            }
        }
        public static customerBL getCustomerByNameAndPassword(string name, string password)
        {
            foreach (customerBL customer in getaddCustomer())
            {
                if (customer.getname() == name && customer.getpassword() == password)
                {
                    return customer;
                }
            }
            return null; 
        }
        

      
    }
}
