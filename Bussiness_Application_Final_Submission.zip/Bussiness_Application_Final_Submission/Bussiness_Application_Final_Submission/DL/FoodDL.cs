﻿using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bussiness_Application_Final_Submission.BL;
using Bussiness_Application_Final_Submission.UI;
using System;

namespace Bussiness_Application_Final_Submission.DL
{
    class FoodDL
    {
        private static List<FoodBL> Products = new List<FoodBL>(); //list to add the details of the noodles
        public static List<FoodBL> sortedList = new List<FoodBL>(); //list to sort the data of noodles

        public static void addFood(FoodBL F) //function to add food object into the list
        {
            Products.Add(F);
        }
        public static void RemoveParticularFood(int index) //ftn to remove the particular index of the nooodles
        {
            Products.RemoveAt(index);
        }
        public static void UpdateRecord(int index, FoodBL F)
        {
            if (index >= 0 && index < Products.Count)
            {
                Products[index].setName(F.getName());
                Products[index].setsalePrice(F.getsalePrice());
                Products[index].setactualPrice(F.getactualPrice());
                Products[index].setstock(F.getstock());
                Products[index].setsdiscount(F.getsdiscount());
                Console.WriteLine("Product at index " + index + " has been updated.");
            }
            else
            {
                Console.WriteLine("Invalid index provided.");
            }
        }
        
        public static List<FoodBL> getProducts() //get ftn of product list
        {
            return Products;
        }
        public static List<FoodBL> sortByPrice() //ftn to sort the data of noodles by price
        {
            List<FoodBL> temp = Products.OrderByDescending(o => o.getsalePrice()).ToList();
            return temp;
        }
        public static List<FoodBL> sortBysold()//ftn to sort the data of noodles by sold
        {
            List<FoodBL> temp = Products.OrderByDescending(o => o.getsold()).ToList();
            return temp;
        }
        public static int GetParticularIndex(string name) //ftn to get the particular index of noodles
        {
            for(int i = 0; i < Products.Count; i++ )
            {
                if(Products[i].getName().ToLower() == name)
                {
                    return i;
                }
            }
            return 5956;
        }
        public static void readNoodlesData(string path1)//filehandling to read data of noodles
        {
            if (File.Exists(path1))
            {

                StreamReader fileVariable = new StreamReader(path1);
                string record;
                while ((record = fileVariable.ReadLine()) != null)
                {
                    NoodlesBL info = new NoodlesBL();
                    info.setName(PersonDL.parseData(record, 1));
                    info.setsalePrice(int.Parse(PersonDL.parseData(record, 2)));
                    info.setstock(int.Parse(PersonDL.parseData(record, 3)));
                    getProducts().Add(info);
                }
                fileVariable.Close();
            }
            else
            {
                FoodUI.readNoodlesData1();
            }
        }
        
        public static void sorting(List<FoodBL> products)//Function for view the Sorted List 
        {
            List<FoodBL> sortedList = products.OrderByDescending(o => o.getsalePrice()).ToList();
            Console.WriteLine("Name\t " + " : " + "Sales price " + " : " + "Stock" + " : " + "Discount");
            foreach (var storedUser in sortedList)
            {
                Console.WriteLine(storedUser.getName() + "\t:\t" + storedUser.getsalePrice() + "\t:\t" + storedUser.getstock() + "\t:\t" + storedUser.getsdiscount());
            }
        }
        public static List<FoodBL> SortByQuntity(List<FoodBL> Products) // ftn to sort the noodles by quantity
        {
            List<FoodBL> sortedList = getProducts().OrderByDescending(o => o.getquantity()).ToList();
            return sortedList;
        }
        public static void writeItemDataInFile(string path1) //ftn to write the data of 
        {
            StreamWriter myfile = new StreamWriter(path1);
            foreach (NoodlesBL storedUser in getProducts())
            {
                myfile.WriteLine(storedUser.getName() + "," + storedUser.getsalePrice() + "," + storedUser.getstock());
            }
            myfile.Flush();
            myfile.Close();
        }
        public static NoodlesBL getProductByName(string name)
        {
            foreach (NoodlesBL product in FoodDL.getProducts())
            {
                if (product.getName() == name)
                {
                    return product;
                }
            }

            return null; // If no matching product is found
        }
    }
}
