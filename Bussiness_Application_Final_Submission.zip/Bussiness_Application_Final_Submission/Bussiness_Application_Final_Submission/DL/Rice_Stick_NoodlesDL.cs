﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application_Final_Submission.DL
{
    class Rice_Stick_NoodlesDL
    {
    }
}
