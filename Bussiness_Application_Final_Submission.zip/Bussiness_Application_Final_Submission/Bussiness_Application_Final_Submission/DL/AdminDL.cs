﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bussiness_Application_Final_Submission.BL;
using Bussiness_Application_Final_Submission.UI;

namespace Bussiness_Application_Final_Submission.DL
{
    class AdminDL //Admin data layer
    {
        public static List<string> feedbackList = new List<string>(); //list to add the feedbacks of the customers
        private List<string> feedback = new List<string>();//list to add the feedbacks
        public void addFeedback(string F) //functon to add object in list
        {
            feedback.Add(F);
        }
        public void setFeedback(List<string> feedback) //set function of list feedbackList
        {
            this.feedback = feedback;
        }
        public List<string> getAllFeedback()//get function of list feedbackList
        {
            return feedback;
        }
        public static double billsCheck(NoodlesBL c) //functionn to make the bill ofthe customer's bought products
        {
            double discount = c.getsdiscount();
            double salePrice = c.getsalePrice();
            int stock = c.getstock();
            if (discount < 0 || discount > 100) //validations
            {
                Console.WriteLine("Invalid discount value. Discount should be between 0 and 100.");
                return 0.0; 
            }
            if (salePrice < 0 || stock < 0)
            {
                Console.WriteLine("Invalid sale price or stock value. They should be non-negative.");
                return 0.0;
            }
            double Discount_bill = c.getsalePrice() * c.getstock() * (c.getsdiscount() / 100);
            double final_bill = c.getsalePrice() - Discount_bill;
            return final_bill;
        }
    }
}
