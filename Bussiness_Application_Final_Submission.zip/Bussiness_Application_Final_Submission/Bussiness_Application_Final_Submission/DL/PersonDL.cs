﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bussiness_Application_Final_Submission.BL;

namespace Bussiness_Application_Final_Submission.DL
{
    class PersonDL
    {
        public static List<PersonBL> user = new List<PersonBL>(); //list to add users

        public static PersonBL signIn(PersonBL u) //ftn to sign in the user
        {

            foreach (PersonBL storedUser in user)
            {
                if (u.getname() == storedUser.getname() && u.getpassword() == storedUser.getpassword())
                {
                    return storedUser;
                }
            }
            return null;
        }
        public static void storeDataInList(PersonBL users) //ftn to store the data of the noodles in the file
        {
            user.Add(users);
        }
        public static void storeDataInFile(string path, PersonBL user)//ftn to store data of the user in the file
        {
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(user.getname() + "," + user.getpassword() + "," + user.getRole());
            file.Flush();
            file.Close();
        }
        public static void readData(string path)//ftn to read the data of the noodles from file
        {
            if (File.Exists(path))
            {
                StreamReader fileVariable = new StreamReader(path);
                string record;
                while ((record = fileVariable.ReadLine()) != null)
                {
                    string names = parseData(record, 1);
                    string password = parseData(record, 2);
                    string role = parseData(record, 3);
                    PersonBL o = new PersonBL(names, password, role);
                    if (role == "customer" || role == "Customer")
                    {
                        customerDL.addCustomerInList(new customerBL(names, password, role));
                    }
                    user.Add(o);
                    Console.ReadKey();
                }
                fileVariable.Close();
            }
            else
            {
                Console.Write("Doesnot Exists");
            }
        }
        public static void signUp(string path, string n, string p, ref int usersCount, ref int userArrSize) //sign up function for the usserq
        {
            StreamWriter myfile = new StreamWriter(path, true);
            myfile.WriteLine(n + "," + p);
            myfile.Flush();
            myfile.Close();
            if (usersCount < userArrSize)
            {
                user[usersCount] = addUserData(n, p);
                usersCount++;
            }
        }
        public static PersonBL addUserData(string n, string p)//ftn to as add user name and the password
        {
            PersonBL s1 = new PersonBL();
            s1.setname(n);
            s1.setpassword(p);
            return s1;
        }
        public static string parseData(string record, int field)//ftn used in storing data of both products and the user
        {
            int comma = 1;
            string item = "";
            for (int x = 0; x < record.Length; x++)
            {
                if (record[x] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + record[x];

                }
            }
            return item;
        }
        public static void addObjectIntoList(PersonBL person)//Function to add User object into the list
        {
            user.Add(person);
        }
        public static void setObjectInList(PersonBL user)//ftn to add usuer object in list
        {
            addObjectIntoList(user);
        }
    }
}
