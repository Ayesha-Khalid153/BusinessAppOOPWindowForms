﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bussiness_Application_Final_Submission.UI;
using Bussiness_Application_Final_Submission.BL;

namespace Bussiness_Application_Final_Submission.DL
{
    class NoodlesDL
    {
    }
}
