﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Bussiness_Application_Final_Submission.BL;
using Bussiness_Application_Final_Submission.DL;
using Bussiness_Application_Final_Submission.UI;

namespace Application_class
{
    class Program
    {
        static void Main(string[] args)
        {

            string path = "C:\\Users\\Feb12\\Desktop\\data.txt";
            string path1 = "C:\\Users\\Feb12\\Desktop\\noodles.txt";

            FoodDL.readNoodlesData(path1);
            string option;
            PersonDL.readData(path);

            do
            {
                Console.Clear();
                NoodlesUI.topHeader();//ftn to print header
                NoodlesUI.logo();//ftn to print logo
                option = PersonUI.Menu();//taking option equals to main menu of user
                Console.Clear();
                if (option == "1")
                {
                    Console.Clear();
                    NoodlesUI.topHeader();//ftn to print header
                    NoodlesUI.logo();//ftn to print logo
                    PersonBL user = PersonUI.takeInputWithRole();//ftn to take input of user with role
                    PersonDL.setObjectInList(user);
                    if (user != null)
                    {
                        if (user.getRole() == "customer" || user.getRole() == "Customer")
                        {
                            customerDL.addCustomerInList(new customerBL(user.getname(), user.getpassword(), user.getRole()));
                            Console.ReadKey();
                        }
                        PersonDL.storeDataInFile(path, user);//ftn to store data in file
                        PersonDL.storeDataInList(user);//ftn to store data in list

                    }
                }
                else if (option == "2")
                {
                    Console.Clear();
                    NoodlesUI.topHeader();//ftn to print header
                    NoodlesUI.logo();//ftn to print logo
                    PersonBL user = PersonUI.takeInputWithoutRole();//ftn to take input of user without role
                    PersonDL.storeDataInList(user);
                    if (user != null)
                    {
                        user = PersonDL.signIn(user);//ftn to sgn in the user
                        if (user == null)
                        {
                            Console.WriteLine("INVALID INPUT!");
                        }
                        else if (user.getRole() == "admin")//condition to check if the info is correct or not
                        {
                            Console.WriteLine("Admin menu");
                            AdminUI.adminInterface(path1);//admin interface is called here
                        }
                        else if (user.getRole() == "customer")//condition to check if the info is correct or not
                        {
                            Console.WriteLine("Customer Menu");
                            customerUI.customerInterface();//customer interface is called here
                        }
                        else
                        {
                            Console.WriteLine("INVALID USER!");
                        }
                    }
                    Console.ReadKey();
                }
            }
            while (option != "3");//condition 
            Console.ReadKey();
        }
    }

}


