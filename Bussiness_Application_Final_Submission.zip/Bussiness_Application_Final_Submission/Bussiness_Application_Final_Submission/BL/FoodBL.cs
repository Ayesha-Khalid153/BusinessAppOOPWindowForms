﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application_Final_Submission.BL
{
    public class FoodBL //parent class 
    {//attributes
        protected string name;
        protected double actualPrice;
        protected double salePrice;
        protected int stock;
        protected double discount;
        protected int sold = 0;
        protected int quantity;
        protected double bill;

        public FoodBL() { }//default constructor
        public FoodBL(string name, double actualPrice, double salePrice, int stock, double discount)//constructor with five attributes
        {
            this.actualPrice = actualPrice;
            this.discount = discount;
            this.name = name;
            this.salePrice = salePrice;
            this.stock = stock;
        }
        public FoodBL(string name, double actualPrice, double salePrice, int stock, double discount,int quantity)//constructor with five attributes
        {
            this.actualPrice = actualPrice;
            this.discount = discount;
            this.name = name;
            this.salePrice = salePrice;
            this.stock = stock;
            this.quantity = quantity;
        }

        public void setsold(int stock)//setter ftn for the stock which is sold
        {
            this.sold = this.sold + stock;
        }
        public int getsold()//getter ftn for the stock which is sold
        {
            return this.sold;
        }
        public void setName(string name)//setter ftn for the name of noodles
        {
            this.name = name;
        }
        public string getName()//getter ftn for the name of the noodles
        {
            return name;
        }

        public void setactualPrice(double actualPrice)//setter ftn for actual price of noodles
        {
            this.actualPrice = actualPrice;
        }
        public double getactualPrice()//getter ftn for actual price of noodles
        {
            return actualPrice;
        }
        public void setquantity(int quantity)//setter ftn for quantity of noodles
        {
            this.quantity = quantity;
        }
        public int getquantity()//getter ftn for the quantity of noodles
        {
            return quantity;
        }
        public void setsalePrice(double salePrice)//setter ftn for sales price of noodles
        {
            this.salePrice = salePrice;
        }
        public double getsalePrice()//getter ftn for the sales price
        {
            return salePrice;
        }

        public void setstock(int stock)//setter ftn for stock of noodles
        {
            this.stock = stock;
        }
        public int getstock()//getter ftn for the stock
        {
            return stock;
        }

        public void setsdiscount(double discount)//setter ftn for disvcount of noodles
        {
            this.discount = discount;
        }
        public double getsdiscount()//getter ftn for the discounts
        {
            return discount;
        }
        public void setbill(double bill)//setter ftn for bill of noodles
        {
            this.bill = bill;
        }
        public double getbill()//getter ftn for the bill
        {
            return bill;
        }


    }
}
