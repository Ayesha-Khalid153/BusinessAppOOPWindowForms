﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application_Final_Submission.BL
{
    class PersonBL //parent class
    { 
        protected string name;
        protected string password;
        protected string role;
        

        public PersonBL() { }//default constructor
        public PersonBL(string name, string password) //constructor with two parameters
        {
            this.name = name;
            this.password = password;
        }
        public PersonBL(string name, string password, string role) //constructor with three parameters
        {
            this.name = name;
            this.password = password;
            this.role = role;
        }


        public virtual void setRole(string role)//setter virtual function of role
        {
            this.role = role;
        }
        public virtual string getRole()//getter virtual function of the role
        {
            return role;
        }
        public void setname(string name)//setter function for name of the user
        {
            this.name = name;
        }
        public string getname()//getter function for the name
        {
            return name;
        }
        public void setpassword(string password)//setter function for the password
        {
            this.password = password;
        }
        public string getpassword()//getter function for the password
        {
            return password;
        }

    }
}
