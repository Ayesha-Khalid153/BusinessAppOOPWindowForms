﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application_Final_Submission.BL
{
    class AdminBL : PersonBL//admin is a child class having personBL as a parent
    {
        private List<FoodBL> products = new List<FoodBL>();//list to store product details
        

        public AdminBL() { }//default constructors
        public AdminBL(string name, string password,string role) : base(name,password,role)//constructor with three attributes
        {
            this.name = name;
            this.password = password;
            this.role = role;
            
        }
        public AdminBL(string name, string password) : base(name,password)//constructor with two attributes
        {
            this.name = name;
            this.password = password;
        }
        public void addProducts(FoodBL F)//ftn to add product in list
        {
            products.Add(F);
        }
        public void setAllProducts(List<FoodBL> products)//ftn to set all he products
        {
            this.products = products;
        }
        public List<FoodBL> getAllProducts()//ftn to get all the products
        {
            return products;
        }

        public void addDiscount(FoodBL F)//ftn to add discount in list
        {
            products.Add(F);
        }
        public void setDiscount(List<FoodBL> products)//discount setter function
        {
            this.products = products;
        }
        public List<FoodBL> getDiscount()//discount getter ftn
        {
            return products;
        }

        public void makeBill(FoodBL F)//add bought products in list
        {
            products.Add(F);
        }
        public void setBill(List<FoodBL> products)//setter ftn of bill
        {
            this.products = products;
        }
        public List<FoodBL> getBill()//getter ftn of bill
        {
            return products;
        }

        public void deleteProducts(int index)//ftn todelete fproducts
        {
            products.RemoveAt(index);
        }



        public override void setRole(string role)//role setter ftn overrided from parent class personBL
        {
            this.role = "admin";
        }
        public override string getRole()//role getter ftn overrided from parent class personBL
        {
            return role;
        }


    }
}
