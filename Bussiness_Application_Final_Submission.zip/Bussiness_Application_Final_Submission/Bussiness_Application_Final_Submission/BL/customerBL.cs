﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application_Final_Submission.BL
{
    class customerBL : PersonBL
    {
        //attributes of the child class customer
        private string adress;
        private string email;
        private string contact;

        public static List<FoodBL> ProductBuy = new List<FoodBL>() ;//list to store the bought noodles

        public static List<FoodBL> getBuyProducts()//getter ftn of customer bought object list
        {
            return ProductBuy;
        }
        public string getEmail()//getter ftn of customer email
        {
            return email;
        }
        public void setemail(string email)//setter function of customer email
        {
            this.email = email;
        }

        public customerBL(string name, string password, string role) : base(name, password, role) //constructor of child class accessing the attribute from the (base) parent class with role
        {
            ProductBuy = new List<FoodBL>();
        }
        public customerBL(string name, string password, string adress, string contact, string email) : base(name, password)//constructor of child class accessing the attribute from the (base) parent class withlout role
        {
            this.adress = adress;
            this.contact = contact;
            this.email = email;
        }

        public customerBL() { }//default constructor

        public customerBL(string name, string password) : base(name, password)//constructor with two parameters of child class
        {
            this.name = name;
            this.password = password;
        }

        public override void setRole(string role)//setter function of role
        {
            this.role = "customer";
        }
        public override string getRole()//getter function of role
        {
            return role;
        }
        public static void addBuyProduct(NoodlesBL product)
        {
            ProductBuy.Add(product);
        }
        public void addbuyProduct(FoodBL F)//ftn to add bought noodles in list
        {
            ProductBuy.Add(F);
        }
        public List<FoodBL> viewAllProducts()//ftn to view all the noodles data  stored in list
        {
            return ProductBuy;
        }

        public static void add_item_Info_InList(FoodBL i)//ftn to add noodles data in list
        {
            ProductBuy.Add(i);
        }
    }
}
