﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application_Final_Submission.BL
{
    class Ho_Fun_Noodles : NoodlesBL//grand child of personBL and child of NoodlesBL
    {
        public override void setTasteMaker(string tasteMaker)//setter overrided ftn of tastemaker of noodles
        {
            this.tasteMaker = tasteMaker;
        }
        public override string getTasteMaker()//getter overrided ftn of tastemaker of noodles
        {
            return tasteMaker;
        }
    }
}
