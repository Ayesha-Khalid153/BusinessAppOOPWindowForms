﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application_Final_Submission.BL
{
    class NoodlesBL : FoodBL//NoodlesBL is child class of parent class FoodBL
    {
        protected string tasteMaker;//attribute

        public NoodlesBL() { }//default constructor
        public NoodlesBL(string name, double actualPrice, double salePrice, int stock, double discount,string tasteMaker) : base (name,actualPrice,salePrice, stock, discount)//constructor with all the attributes
        {
            this.tasteMaker = tasteMaker;
        }
        public NoodlesBL(string name, double salePrice, double discount, int quantity)
        {
            this.name = name;
            this.salePrice = salePrice;
            this.discount = discount;
            this.quantity = quantity;
        }
        public virtual void setTasteMaker(string tasteMaker)//setter virtual ftn of tastemaker of noodles
        {                                                   
            this.tasteMaker = tasteMaker;
        }
        public virtual string getTasteMaker()//getter virtual ftn of tastemaker of noodles
        {
            return tasteMaker;
        }

    }
}
